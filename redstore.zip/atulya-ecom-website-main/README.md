# atulya-ecom-website
This is simple frontend UI of an E-commerce website. It includes home page, product page, about page, sign up page and card page. It is using Html,Css and Javascript. 
